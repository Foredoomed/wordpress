	<div id="footer">
		<p class="left">&#169; <?php echo date('Y');?> <strong><?php bloginfo('name'); ?></strong> | Powered by <strong><a href="http://wordpress.org/">WordPress</a></strong></p>
		<p class="right">A <strong><a href="http://www.techtrot.com/primepress/" title="PrimePress theme homepage">WordPress theme</a></strong> by <strong>Ravi Varma</strong></p>
	</div><!--#footer-->

</div><!--#container-->	
	
</div><!--#page-->
<?php wp_footer(); ?>
</body>
</html>