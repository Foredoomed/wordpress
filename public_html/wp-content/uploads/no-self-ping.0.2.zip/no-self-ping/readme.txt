=== No Self Pings ===
Contributors: mdawaffe
Tags: pingback
Tested up to: 3.0
Stable tag: 0.2

Keeps WordPress from sending pings to your own site.

== Description ==

Some people really like that WordPress sends pings from your own site to your own site when you write posts; it gives them a trail of related posts.

Some people do not like this behavior; it clutters up their comments.

This plugin disables intra-blog pinging.

== Installation ==

Activate the plugin.  That's it.  No configuration.
